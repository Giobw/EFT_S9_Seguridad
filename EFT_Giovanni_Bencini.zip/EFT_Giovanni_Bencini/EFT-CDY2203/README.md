# Sistema de Gestion Veterinaria - EFT CDY2203

Backend Spring Boot 4.1.1 (Spring Framework 7, Spring Security 7) con Spring Security (JWT + roles), JPA/MySQL, iText (facturas PDF).

## Roles
| Rol | Acceso |
|---|---|
| ROLE_ADMIN | Todo (pacientes, citas, servicios, medicamentos, facturas, borrados) |
| ROLE_VETERINARIO | Leer y crear pacientes, citas, servicios y medicamentos |

## Puesta en marcha (PowerShell)
```powershell
# 1) Variables de entorno (elige tus propias claves)
$env:DB_ROOT_PASSWORD = "<clave-root-mysql>"
$env:DB_USER = "myuser"
$env:DB_PASSWORD = "<clave-db>"
$b = New-Object byte[] 48; [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b)
$env:JWT_SECRET = [Convert]::ToBase64String($b)
$env:ADMIN_INITIAL_PASSWORD = "<clave-admin>"
$env:VET_INITIAL_PASSWORD = "<clave-veterinario>"

# 2) Base de datos (crea las tablas con database/schema.sql)
docker compose up -d --build

# 3) Aplicacion
./mvnw spring-boot:run          # http://localhost:8180
```

## Probar
```powershell
# login -> devuelve "Bearer <token>"
curl -X POST http://localhost:8180/login -H "Content-Type: application/json" -d '{"username":"admin","password":"<clave-admin>"}'
```

## Pruebas y cobertura (no necesitan MySQL: usan H2 en memoria)
```powershell
./mvnw clean verify             # reporte: target/site/jacoco/index.html
```
