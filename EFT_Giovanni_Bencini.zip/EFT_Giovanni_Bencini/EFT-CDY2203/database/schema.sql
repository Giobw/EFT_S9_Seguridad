-- Esquema de la base de datos del Sistema de Gestion Veterinaria (MySQL 8.4)
-- Se ejecuta automaticamente la primera vez que arranca el contenedor Docker.

CREATE TABLE IF NOT EXISTS users (
    id         INT          NOT NULL AUTO_INCREMENT,
    username   VARCHAR(50)  NOT NULL,
    email      VARCHAR(100),
    password   VARCHAR(100) NOT NULL,          -- hash BCrypt, nunca texto plano
    role       VARCHAR(30)  NOT NULL,          -- ROLE_ADMIN | ROLE_VETERINARIO
    enabled    BIT(1)       NOT NULL DEFAULT b'1',
    PRIMARY KEY (id),
    CONSTRAINT uk_users_username UNIQUE (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS patient (
    id       BIGINT       NOT NULL AUTO_INCREMENT,
    name     VARCHAR(100) NOT NULL,
    species  VARCHAR(50)  NOT NULL,
    breed    VARCHAR(50),
    age      INT          NOT NULL,
    owner    VARCHAR(100) NOT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS appointment (
    id               BIGINT       NOT NULL AUTO_INCREMENT,
    appointment_date DATE         NOT NULL,
    appointment_time TIME         NOT NULL,
    reason           VARCHAR(200) NOT NULL,
    veterinarian     VARCHAR(100) NOT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS care (
    id    BIGINT       NOT NULL AUTO_INCREMENT,
    name  VARCHAR(100) NOT NULL,
    cost  DOUBLE       NOT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS medication (
    id    BIGINT       NOT NULL AUTO_INCREMENT,
    name  VARCHAR(100) NOT NULL,
    cost  DOUBLE       NOT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS invoice (
    id            BIGINT       NOT NULL AUTO_INCREMENT,
    patient_name  VARCHAR(100) NOT NULL,
    invoice_date  DATE         NOT NULL,
    invoice_time  TIME,
    total_cost    DOUBLE,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS invoice_cares (
    invoice_id BIGINT NOT NULL,
    care_id    BIGINT NOT NULL,
    PRIMARY KEY (invoice_id, care_id),
    CONSTRAINT fk_invoice_cares_invoice FOREIGN KEY (invoice_id) REFERENCES invoice (id) ON DELETE CASCADE,
    CONSTRAINT fk_invoice_cares_care    FOREIGN KEY (care_id)    REFERENCES care (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS invoice_medications (
    invoice_id    BIGINT NOT NULL,
    medication_id BIGINT NOT NULL,
    PRIMARY KEY (invoice_id, medication_id),
    CONSTRAINT fk_invoice_meds_invoice FOREIGN KEY (invoice_id)    REFERENCES invoice (id) ON DELETE CASCADE,
    CONSTRAINT fk_invoice_meds_med     FOREIGN KEY (medication_id) REFERENCES medication (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
