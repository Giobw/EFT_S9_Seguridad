package com.duoc.backend;

public final class Constants {

    private Constants() {
    }

    // Spring Security
    public static final String LOGIN_URL = "/login";
    public static final String HEADER_AUTHORIZACION_KEY = "Authorization";
    public static final String TOKEN_BEARER_PREFIX = "Bearer ";

    // JWT (la clave de firma NO esta aqui: viene de la propiedad app.jwt.secret)
    public static final String ISSUER_INFO = "https://www.duocuc.cl/";
    public static final String CLAIM_AUTHORITIES = "authorities";

    // Roles
    public static final String ROLE_ADMIN = "ROLE_ADMIN";
    public static final String ROLE_VETERINARIO = "ROLE_VETERINARIO";
}
