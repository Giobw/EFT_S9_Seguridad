package com.duoc.backend;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.duoc.backend.user.User;
import com.duoc.backend.user.UserRepository;

/**
 * Crea los usuarios iniciales (admin y veterinario) con clave cifrada con BCrypt.
 * Las claves se entregan por variables de entorno; si no vienen, no se crea nada.
 */
@Component
public class DataInitializer implements ApplicationRunner {

    private static final Logger LOGGER = LoggerFactory.getLogger(DataInitializer.class);

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final String adminPassword;
    private final String vetPassword;

    public DataInitializer(UserRepository userRepository, PasswordEncoder passwordEncoder,
            @Value("${app.bootstrap.admin-password:}") String adminPassword,
            @Value("${app.bootstrap.vet-password:}") String vetPassword) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.adminPassword = adminPassword;
        this.vetPassword = vetPassword;
    }

    @Override
    public void run(ApplicationArguments args) {
        createIfMissing("admin", "admin@veterinaria.cl", adminPassword, Constants.ROLE_ADMIN);
        createIfMissing("veterinario", "vet@veterinaria.cl", vetPassword, Constants.ROLE_VETERINARIO);
    }

    private void createIfMissing(String username, String email, String rawSecret, String role) {
        if (rawSecret == null || rawSecret.isBlank()) {
            LOGGER.info("Usuario inicial '{}' no creado: no se definio su clave inicial", username);
            return;
        }
        if (userRepository.findByUsername(username) != null) {
            return;
        }
        userRepository.save(new User(username, email, passwordEncoder.encode(rawSecret), role, true));
        LOGGER.info("Usuario inicial '{}' creado", username);
    }
}
