package com.duoc.backend.Invoice;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.duoc.backend.care.Care;
import com.duoc.backend.medication.Medication;
import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/invoice")
public class InvoiceController {

    private static final Logger LOGGER = LoggerFactory.getLogger(InvoiceController.class);

    private final InvoiceService invoiceService;

    public InvoiceController(InvoiceService invoiceService) {
        this.invoiceService = invoiceService;
    }

    @GetMapping
    public List<Invoice> getAllInvoices() {
        return invoiceService.getAllInvoices();
    }

    @GetMapping("/{id}")
    public Invoice getInvoiceById(@PathVariable Long id) {
        Invoice invoice = invoiceService.getInvoiceById(id);
        if (invoice == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Factura no encontrada");
        }
        return invoice;
    }

    @PostMapping
    public Invoice saveInvoice(@Valid @RequestBody InvoiceRequest request) {
        return invoiceService.saveInvoice(request);
    }

    @DeleteMapping("/{id}")
    public void deleteInvoice(@PathVariable Long id) {
        invoiceService.deleteInvoice(id);
    }

    @GetMapping("/pdf/{id}")
    public ResponseEntity<byte[]> generateInvoicePdf(@PathVariable Long id) {
        Invoice invoice = invoiceService.getInvoiceById(id);
        if (invoice == null) {
            return ResponseEntity.notFound().build();
        }

        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            PdfDocument pdfDocument = new PdfDocument(new PdfWriter(out));
            Document document = new Document(pdfDocument);

            Paragraph title = new Paragraph("Veterinaria Mi Mascota")
                    .setFont(PdfFontFactory.createFont(StandardFonts.HELVETICA_BOLD))
                    .setFontSize(24)
                    .setTextAlignment(TextAlignment.CENTER);
            document.add(title);
            document.add(new Paragraph("\n"));

            document.add(new Paragraph("Factura ID: " + invoice.getId()));
            document.add(new Paragraph("Paciente: " + invoice.getPatientName()));
            document.add(new Paragraph("Fecha: " + invoice.getDate()));
            document.add(new Paragraph("\n"));

            Table table = new Table(2);
            table.setWidth(UnitValue.createPercentValue(100));
            table.addCell("Descripción");
            table.addCell("Costo");

            for (Care care : invoice.getCares()) {
                table.addCell(care.getName());
                table.addCell("$" + care.getCost());
            }
            for (Medication medication : invoice.getMedications()) {
                table.addCell(medication.getName());
                table.addCell("$" + medication.getCost());
            }
            document.add(table);

            document.add(new Paragraph("\nTotal: $" + invoice.getTotalCost()));
            document.close();

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDisposition(ContentDisposition.attachment().filename("invoice_" + id + ".pdf").build());

            return ResponseEntity.ok().headers(headers).body(out.toByteArray());
        } catch (IOException | RuntimeException e) {
            LOGGER.error("No se pudo generar el PDF de la factura {}", id, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
