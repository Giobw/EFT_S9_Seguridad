package com.duoc.backend.Invoice;

import java.time.LocalDate;
import java.util.List;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import static com.duoc.backend.ValidationPatterns.MENSAJE_SIN_ETIQUETAS;
import static com.duoc.backend.ValidationPatterns.SIN_ETIQUETAS_HTML;

/** Datos para crear una factura: el costo total lo calcula el servidor, nunca el cliente. */
public record InvoiceRequest(
        @NotBlank @Size(max = 100) @Pattern(regexp = SIN_ETIQUETAS_HTML, message = MENSAJE_SIN_ETIQUETAS) String patientName,
        @NotNull LocalDate date,
        @NotNull @Size(max = 50) List<Long> careIds,
        @NotNull @Size(max = 50) List<Long> medicationIds) {
}
