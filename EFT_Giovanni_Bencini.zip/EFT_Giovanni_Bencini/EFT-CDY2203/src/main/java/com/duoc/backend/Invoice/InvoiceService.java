package com.duoc.backend.Invoice;

import java.time.LocalTime;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.duoc.backend.care.Care;
import com.duoc.backend.care.CareRepository;
import com.duoc.backend.medication.Medication;
import com.duoc.backend.medication.MedicationRepository;

@Service
public class InvoiceService {

    private final InvoiceRepository invoiceRepository;
    private final MedicationRepository medicationRepository;
    private final CareRepository careRepository;

    public InvoiceService(InvoiceRepository invoiceRepository, MedicationRepository medicationRepository,
            CareRepository careRepository) {
        this.invoiceRepository = invoiceRepository;
        this.medicationRepository = medicationRepository;
        this.careRepository = careRepository;
    }

    public List<Invoice> getAllInvoices() {
        return invoiceRepository.findAll();
    }

    public Invoice getInvoiceById(Long id) {
        return invoiceRepository.findById(id).orElse(null);
    }

    @Transactional
    public Invoice saveInvoice(InvoiceRequest request) {
        List<Medication> medications = medicationRepository.findAllById(request.medicationIds());
        if (medications.size() != request.medicationIds().stream().distinct().count()) {
            throw new IllegalArgumentException("Algunos medicamentos no existen en la base de datos.");
        }

        List<Care> cares = careRepository.findAllById(request.careIds());
        if (cares.size() != request.careIds().stream().distinct().count()) {
            throw new IllegalArgumentException("Algunos servicios no existen en la base de datos.");
        }

        double totalCareCost = cares.stream().mapToDouble(Care::getCost).sum();
        double totalMedicationCost = medications.stream().mapToDouble(Medication::getCost).sum();

        Invoice invoice = new Invoice(null, request.patientName(), request.date(), cares, medications);
        invoice.setTime(LocalTime.now());
        invoice.setTotalCost(totalCareCost + totalMedicationCost);

        return invoiceRepository.save(invoice);
    }

    public void deleteInvoice(Long id) {
        invoiceRepository.deleteById(id);
    }
}
