package com.duoc.backend;

import static com.duoc.backend.Constants.CLAIM_AUTHORITIES;
import static com.duoc.backend.Constants.ISSUER_INFO;
import static com.duoc.backend.Constants.TOKEN_BEARER_PREFIX;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Component
public class JWTAuthenticationConfig {

    private static final int MIN_KEY_BYTES = 32;

    private final SecretKey signingKey;
    private final long expirationMs;

    public JWTAuthenticationConfig(@Value("${app.jwt.secret}") String secret,
            @Value("${app.jwt.expiration-ms:3600000}") long expirationMs) {
        byte[] keyBytes = Decoders.BASE64.decode(secret);
        if (keyBytes.length < MIN_KEY_BYTES) {
            throw new IllegalStateException("app.jwt.secret debe tener al menos 256 bits (32 bytes) codificados en Base64");
        }
        this.signingKey = Keys.hmacShaKeyFor(keyBytes);
        this.expirationMs = expirationMs;
    }

    public String getJWTToken(String username, Collection<? extends GrantedAuthority> authorities) {
        List<String> roles = authorities.stream().map(GrantedAuthority::getAuthority).toList();
        Date now = new Date();

        String token = Jwts.builder()
                .issuer(ISSUER_INFO)
                .subject(username)
                .claim(CLAIM_AUTHORITIES, roles)
                .issuedAt(now)
                .expiration(new Date(now.getTime() + expirationMs))
                .signWith(signingKey)
                .compact();

        return TOKEN_BEARER_PREFIX + token;
    }

    public Claims parseToken(String token) {
        return Jwts.parser()
                .verifyWith(signingKey)
                .requireIssuer(ISSUER_INFO)
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }
}
