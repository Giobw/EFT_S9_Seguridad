package com.duoc.backend;

import static com.duoc.backend.Constants.CLAIM_AUTHORITIES;
import static com.duoc.backend.Constants.HEADER_AUTHORIZACION_KEY;
import static com.duoc.backend.Constants.TOKEN_BEARER_PREFIX;

import java.io.IOException;
import java.util.List;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Valida el token JWT del encabezado Authorization. Se registra solo en la cadena de
 * Spring Security (ver WebSecurityConfig), por eso no es un @Component.
 */
public class JWTAuthorizationFilter extends OncePerRequestFilter {

    private final JWTAuthenticationConfig jwtConfig;

    public JWTAuthorizationFilter(JWTAuthenticationConfig jwtConfig) {
        this.jwtConfig = jwtConfig;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        String header = request.getHeader(HEADER_AUTHORIZACION_KEY);

        if (header != null && header.startsWith(TOKEN_BEARER_PREFIX)) {
            try {
                Claims claims = jwtConfig.parseToken(header.substring(TOKEN_BEARER_PREFIX.length()));
                List<?> roles = claims.get(CLAIM_AUTHORITIES, List.class);
                if (roles == null) {
                    SecurityContextHolder.clearContext();
                } else {
                    var authorities = roles.stream()
                            .map(String::valueOf)
                            .map(SimpleGrantedAuthority::new)
                            .toList();
                    SecurityContextHolder.getContext().setAuthentication(
                            new UsernamePasswordAuthenticationToken(claims.getSubject(), null, authorities));
                }
            } catch (JwtException | IllegalArgumentException e) {
                SecurityContextHolder.clearContext();
                response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Token invalido o expirado");
                return;
            }
        }

        filterChain.doFilter(request, response);
    }
}
