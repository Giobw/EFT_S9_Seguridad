package com.duoc.backend;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.duoc.backend.user.MyUserDetailsService;

import jakarta.validation.Valid;

@RestController
public class LoginController {

    private final JWTAuthenticationConfig jwtAuthenticationConfig;
    private final MyUserDetailsService userDetailsService;
    private final PasswordEncoder passwordEncoder;

    public LoginController(JWTAuthenticationConfig jwtAuthenticationConfig, MyUserDetailsService userDetailsService,
            PasswordEncoder passwordEncoder) {
        this.jwtAuthenticationConfig = jwtAuthenticationConfig;
        this.userDetailsService = userDetailsService;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping(Constants.LOGIN_URL)
    public ResponseEntity<String> login(@Valid @RequestBody LoginRequest loginRequest) {
        try {
            UserDetails user = userDetailsService.loadUserByUsername(loginRequest.username());
            if (user.isEnabled() && passwordEncoder.matches(loginRequest.password(), user.getPassword())) {
                return ResponseEntity.ok(jwtAuthenticationConfig.getJWTToken(user.getUsername(), user.getAuthorities()));
            }
        } catch (UsernameNotFoundException e) {
            // Se responde igual que con una clave incorrecta para no revelar si el usuario existe
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Credenciales invalidas");
    }
}
