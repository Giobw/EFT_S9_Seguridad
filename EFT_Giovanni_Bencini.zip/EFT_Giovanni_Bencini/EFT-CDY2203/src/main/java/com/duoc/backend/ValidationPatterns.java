package com.duoc.backend;

/** Reglas de validacion compartidas por los datos de entrada de la API. */
public final class ValidationPatterns {

    private ValidationPatterns() {
    }

    /** Rechaza los caracteres < y > para que no se guarden etiquetas HTML ni scripts en los datos. */
    public static final String SIN_ETIQUETAS_HTML = "^[^<>]*$";
    public static final String MENSAJE_SIN_ETIQUETAS = "No se permiten los caracteres < y >";
}
