package com.duoc.backend.appointment;

import java.time.LocalDate;
import java.time.LocalTime;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import static com.duoc.backend.ValidationPatterns.MENSAJE_SIN_ETIQUETAS;
import static com.duoc.backend.ValidationPatterns.SIN_ETIQUETAS_HTML;

public record AppointmentRequest(
        @NotNull LocalDate date,
        @NotNull LocalTime time,
        @NotBlank @Size(max = 200) @Pattern(regexp = SIN_ETIQUETAS_HTML, message = MENSAJE_SIN_ETIQUETAS) String reason,
        @NotBlank @Size(max = 100) @Pattern(regexp = SIN_ETIQUETAS_HTML, message = MENSAJE_SIN_ETIQUETAS) String veterinarian) {

    public Appointment toEntity() {
        Appointment appointment = new Appointment();
        appointment.setDate(date);
        appointment.setTime(time);
        appointment.setReason(reason);
        appointment.setVeterinarian(veterinarian);
        return appointment;
    }
}
