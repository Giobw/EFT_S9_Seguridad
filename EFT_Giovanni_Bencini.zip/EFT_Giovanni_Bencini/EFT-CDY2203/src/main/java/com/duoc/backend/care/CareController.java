package com.duoc.backend.care;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/care")
public class CareController {

    private final CareService careService;

    public CareController(CareService careService) {
        this.careService = careService;
    }

    @GetMapping
    public List<Care> getAllCares() {
        return careService.getAllCares();
    }

    @GetMapping("/{id}")
    public Care getCareById(@PathVariable Long id) {
        Care care = careService.getCareById(id);
        if (care == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Servicio no encontrado");
        }
        return care;
    }

    @PostMapping
    public Care saveCare(@Valid @RequestBody CareRequest request) {
        return careService.saveCare(request.toEntity());
    }

    @DeleteMapping("/{id}")
    public void deleteCare(@PathVariable Long id) {
        careService.deleteCare(id);
    }
}
