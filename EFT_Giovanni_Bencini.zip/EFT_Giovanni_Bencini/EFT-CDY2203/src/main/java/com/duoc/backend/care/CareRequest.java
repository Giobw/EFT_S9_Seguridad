package com.duoc.backend.care;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;

import static com.duoc.backend.ValidationPatterns.MENSAJE_SIN_ETIQUETAS;
import static com.duoc.backend.ValidationPatterns.SIN_ETIQUETAS_HTML;

public record CareRequest(
        @NotBlank @Size(max = 100) @Pattern(regexp = SIN_ETIQUETAS_HTML, message = MENSAJE_SIN_ETIQUETAS) String name,
        @NotNull @PositiveOrZero Double cost) {

    public Care toEntity() {
        return new Care(name, cost);
    }
}
