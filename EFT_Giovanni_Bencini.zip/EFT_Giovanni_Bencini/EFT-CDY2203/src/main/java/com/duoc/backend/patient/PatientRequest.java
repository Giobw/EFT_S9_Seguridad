package com.duoc.backend.patient;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import static com.duoc.backend.ValidationPatterns.MENSAJE_SIN_ETIQUETAS;
import static com.duoc.backend.ValidationPatterns.SIN_ETIQUETAS_HTML;

public record PatientRequest(
        @NotBlank @Size(max = 100) @Pattern(regexp = SIN_ETIQUETAS_HTML, message = MENSAJE_SIN_ETIQUETAS) String name,
        @NotBlank @Size(max = 50) @Pattern(regexp = SIN_ETIQUETAS_HTML, message = MENSAJE_SIN_ETIQUETAS) String species,
        @Size(max = 50) @Pattern(regexp = SIN_ETIQUETAS_HTML, message = MENSAJE_SIN_ETIQUETAS) String breed,
        @Min(0) @Max(100) int age,
        @NotBlank @Size(max = 100) @Pattern(regexp = SIN_ETIQUETAS_HTML, message = MENSAJE_SIN_ETIQUETAS) String owner) {

    public Patient toEntity() {
        Patient patient = new Patient();
        patient.setName(name);
        patient.setSpecies(species);
        patient.setBreed(breed);
        patient.setAge(age);
        patient.setOwner(owner);
        return patient;
    }
}
