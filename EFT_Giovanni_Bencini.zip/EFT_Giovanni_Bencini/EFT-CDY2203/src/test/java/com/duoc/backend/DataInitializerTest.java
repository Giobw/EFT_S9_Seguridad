package com.duoc.backend;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.duoc.backend.user.User;
import com.duoc.backend.user.UserRepository;

class DataInitializerTest {

    private final UserRepository userRepository = mock(UserRepository.class);
    private final PasswordEncoder passwordEncoder = mock(PasswordEncoder.class);

    @Test
    void createsBothUsersWhenSecretsAreProvided() {
        when(passwordEncoder.encode(any())).thenReturn("hash");
        DataInitializer initializer = new DataInitializer(userRepository, passwordEncoder, "clave-admin", "clave-vet");

        initializer.run(null);

        verify(userRepository, times(2)).save(any(User.class));
    }

    @Test
    void createsNothingWhenSecretsAreBlank() {
        DataInitializer initializer = new DataInitializer(userRepository, passwordEncoder, "", null);

        initializer.run(null);

        verify(userRepository, never()).save(any(User.class));
    }

    @Test
    void doesNotDuplicateExistingUsers() {
        when(userRepository.findByUsername(any())).thenReturn(new User());
        DataInitializer initializer = new DataInitializer(userRepository, passwordEncoder, "clave-admin", "clave-vet");

        initializer.run(null);

        verify(userRepository, never()).save(any(User.class));
    }
}
