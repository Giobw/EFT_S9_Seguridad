package com.duoc.backend;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

class GlobalExceptionHandlerTest {

    private final GlobalExceptionHandler handler = new GlobalExceptionHandler();

    @Test
    void illegalArgumentReturnsBadRequestWithMessage() {
        ResponseEntity<Map<String, String>> response = handler.handleIllegalArgument(new IllegalArgumentException("dato invalido"));

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("dato invalido", response.getBody().get("error"));
    }

    @Test
    void unexpectedErrorDoesNotLeakDetails() {
        ResponseEntity<Map<String, String>> response = handler.handleUnexpected(new IllegalStateException("detalle interno secreto"));

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Error interno del servidor", response.getBody().get("error"));
    }

    @Test
    void dataIntegrityViolationReturnsConflictWithoutDetails() {
        ResponseEntity<Map<String, String>> response = handler.handleDataIntegrity(new DataIntegrityViolationException("fk_detalle_interno"));

        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
        assertFalse(response.getBody().get("error").contains("fk_detalle_interno"));
    }
}
