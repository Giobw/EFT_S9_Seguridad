package com.duoc.backend.Invoice;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;
import org.springframework.web.server.ResponseStatusException;

import com.duoc.backend.care.Care;
import com.duoc.backend.care.CareRepository;
import com.duoc.backend.medication.Medication;
import com.duoc.backend.medication.MedicationRepository;

class InvoiceServiceAndControllerTest {

    private static final LocalDate DATE = LocalDate.of(2026, 10, 9);

    private final InvoiceRepository invoiceRepository = mock(InvoiceRepository.class);
    private final MedicationRepository medicationRepository = mock(MedicationRepository.class);
    private final CareRepository careRepository = mock(CareRepository.class);
    private final InvoiceService service = new InvoiceService(invoiceRepository, medicationRepository, careRepository);

    private final InvoiceService serviceMock = mock(InvoiceService.class);
    private final InvoiceController controller = new InvoiceController(serviceMock);

    private Care care(long id, double cost) {
        Care care = new Care("Consulta", cost);
        care.setId(id);
        return care;
    }

    private Medication medication(long id, double cost) {
        Medication medication = new Medication("Antibiotico", cost);
        medication.setId(id);
        return medication;
    }

    @Test
    void serviceCalculatesTotalOnTheServer() {
        when(careRepository.findAllById(List.of(1L))).thenReturn(List.of(care(1L, 15000.0)));
        when(medicationRepository.findAllById(List.of(2L))).thenReturn(List.of(medication(2L, 6000.0)));
        when(invoiceRepository.save(any(Invoice.class))).thenAnswer(call -> call.getArgument(0));

        Invoice invoice = service.saveInvoice(new InvoiceRequest("Firulais", DATE, List.of(1L), List.of(2L)));

        assertEquals(21000.0, invoice.getTotalCost());
        assertEquals("Firulais", invoice.getPatientName());
        assertNotNull(invoice.getTime());
        assertNull(invoice.getId());
    }

    @Test
    void serviceRejectsUnknownMedication() {
        when(medicationRepository.findAllById(List.of(7L))).thenReturn(List.of());
        InvoiceRequest request = new InvoiceRequest("Firulais", DATE, List.of(), List.of(7L));

        assertThrows(IllegalArgumentException.class, () -> service.saveInvoice(request));
    }

    @Test
    void serviceRejectsUnknownCare() {
        when(medicationRepository.findAllById(List.of())).thenReturn(List.of());
        when(careRepository.findAllById(List.of(8L))).thenReturn(List.of());
        InvoiceRequest request = new InvoiceRequest("Firulais", DATE, List.of(8L), List.of());

        assertThrows(IllegalArgumentException.class, () -> service.saveInvoice(request));
    }

    @Test
    void serviceListsFindsAndDeletes() {
        Invoice invoice = new Invoice(1L, "Firulais", DATE, List.of(), List.of());
        when(invoiceRepository.findAll()).thenReturn(List.of(invoice));
        when(invoiceRepository.findById(1L)).thenReturn(Optional.of(invoice));
        when(invoiceRepository.findById(2L)).thenReturn(Optional.empty());

        assertEquals(1, service.getAllInvoices().size());
        assertSame(invoice, service.getInvoiceById(1L));
        assertNull(service.getInvoiceById(2L));
        service.deleteInvoice(1L);
        verify(invoiceRepository).deleteById(1L);
    }

    @Test
    void entityAccessorsWork() {
        Invoice invoice = new Invoice();
        invoice.setId(9L);
        invoice.setPatientName("Michi");
        invoice.setDate(DATE);
        invoice.setCares(List.of());
        invoice.setMedications(List.of());
        invoice.setTotalCost(100.0);

        assertEquals(9L, invoice.getId());
        assertEquals("Michi", invoice.getPatientName());
        assertEquals(DATE, invoice.getDate());
        assertEquals(100.0, invoice.getTotalCost());
        assertTrue(invoice.getCares().isEmpty());
        assertTrue(invoice.getMedications().isEmpty());
    }

    @Test
    void controllerHandlesCrudOperations() {
        Invoice invoice = new Invoice(1L, "Firulais", DATE, List.of(), List.of());
        InvoiceRequest request = new InvoiceRequest("Firulais", DATE, List.of(), List.of());
        when(serviceMock.getAllInvoices()).thenReturn(List.of(invoice));
        when(serviceMock.getInvoiceById(1L)).thenReturn(invoice);
        when(serviceMock.getInvoiceById(99L)).thenReturn(null);
        when(serviceMock.saveInvoice(request)).thenReturn(invoice);

        assertEquals(1, controller.getAllInvoices().size());
        assertSame(invoice, controller.getInvoiceById(1L));
        assertThrows(ResponseStatusException.class, () -> controller.getInvoiceById(99L));
        assertSame(invoice, controller.saveInvoice(request));
        controller.deleteInvoice(1L);
        verify(serviceMock).deleteInvoice(1L);
    }

    @Test
    void controllerGeneratesPdf() {
        Invoice invoice = new Invoice(1L, "Firulais", DATE, List.of(care(1L, 50.0)), List.of(medication(2L, 30.0)));
        invoice.setTotalCost(80.0);
        when(serviceMock.getInvoiceById(1L)).thenReturn(invoice);

        ResponseEntity<byte[]> response = controller.generateInvoicePdf(1L);

        assertEquals(200, response.getStatusCode().value());
        assertEquals("application/pdf", response.getHeaders().getContentType().toString());
        assertTrue(response.getBody().length > 0);
    }

    @Test
    void controllerReturnsNotFoundForMissingPdf() {
        when(serviceMock.getInvoiceById(99L)).thenReturn(null);

        assertEquals(404, controller.generateInvoicePdf(99L).getStatusCode().value());
    }

    @Test
    void controllerReturnsServerErrorWhenInvoiceIsBroken() {
        Invoice broken = new Invoice(5L, "Firulais", DATE, null, null);
        when(serviceMock.getInvoiceById(5L)).thenReturn(broken);

        assertEquals(500, controller.generateInvoicePdf(5L).getStatusCode().value());
    }
}
