package com.duoc.backend;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;

class JWTAuthenticationConfigTest {

    private static final String KEY_A = Base64.getEncoder()
            .encodeToString("0123456789abcdef0123456789abcdef".getBytes(StandardCharsets.UTF_8));
    private static final String KEY_B = Base64.getEncoder()
            .encodeToString("fedcba9876543210fedcba9876543210".getBytes(StandardCharsets.UTF_8));

    private final JWTAuthenticationConfig config = new JWTAuthenticationConfig(KEY_A, 60_000);

    @Test
    void generatedTokenCanBeParsedBack() {
        String bearer = config.getJWTToken("admin", List.of(new SimpleGrantedAuthority(Constants.ROLE_ADMIN)));

        assertTrue(bearer.startsWith(Constants.TOKEN_BEARER_PREFIX));
        Claims claims = config.parseToken(bearer.substring(Constants.TOKEN_BEARER_PREFIX.length()));

        assertEquals("admin", claims.getSubject());
        assertEquals(Constants.ISSUER_INFO, claims.getIssuer());
        assertEquals(List.of(Constants.ROLE_ADMIN), claims.get(Constants.CLAIM_AUTHORITIES, List.class));
    }

    @Test
    void tooShortKeyIsRejected() {
        String shortKey = Base64.getEncoder().encodeToString("corta".getBytes(StandardCharsets.UTF_8));

        assertThrows(IllegalStateException.class, () -> new JWTAuthenticationConfig(shortKey, 1000));
    }

    @Test
    void tamperedTokenIsRejected() {
        String token = config.getJWTToken("admin", List.of()).substring(Constants.TOKEN_BEARER_PREFIX.length());

        assertThrows(JwtException.class, () -> config.parseToken(token + "x"));
    }

    @Test
    void tokenSignedWithAnotherKeyIsRejected() {
        String foreign = new JWTAuthenticationConfig(KEY_B, 60_000).getJWTToken("admin", List.of())
                .substring(Constants.TOKEN_BEARER_PREFIX.length());

        assertThrows(JwtException.class, () -> config.parseToken(foreign));
    }

    @Test
    void expiredTokenIsRejected() {
        String expired = new JWTAuthenticationConfig(KEY_A, -1000).getJWTToken("admin", List.of())
                .substring(Constants.TOKEN_BEARER_PREFIX.length());

        assertThrows(JwtException.class, () -> config.parseToken(expired));
    }
}
