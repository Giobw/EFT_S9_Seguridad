package com.duoc.backend;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.duoc.backend.Invoice.InvoiceRepository;
import com.duoc.backend.appointment.AppointmentRepository;
import com.duoc.backend.care.CareRepository;
import com.duoc.backend.medication.MedicationRepository;
import com.duoc.backend.patient.PatientRepository;
import com.duoc.backend.user.User;
import com.duoc.backend.user.UserRepository;
import tools.jackson.databind.ObjectMapper;

/** Pruebas de integracion con la cadena de seguridad real (JWT + roles) sobre H2 en memoria. */
@SpringBootTest
@AutoConfigureMockMvc
class SecurityIntegrationTest {

    private static final String ADMIN_SECRET = "Admin#2026-prueba";
    private static final String VET_SECRET = "Vet#2026-prueba";
    private static final String AUTH = "Authorization";

    @Autowired
    private MockMvc mvc;
    @Autowired
    private ObjectMapper mapper;
    @Autowired
    private PasswordEncoder encoder;
    @Autowired
    private UserRepository users;
    @Autowired
    private PatientRepository patients;
    @Autowired
    private AppointmentRepository appointments;
    @Autowired
    private CareRepository cares;
    @Autowired
    private MedicationRepository medications;
    @Autowired
    private InvoiceRepository invoices;
    @Value("${app.jwt.secret}")
    private String jwtSigningKey;

    @BeforeEach
    void setUp() {
        invoices.deleteAll();
        cares.deleteAll();
        medications.deleteAll();
        patients.deleteAll();
        appointments.deleteAll();
        users.deleteAll();
        users.save(new User("admin", "admin@test.cl", encoder.encode(ADMIN_SECRET), Constants.ROLE_ADMIN, true));
        users.save(new User("veterinario", "vet@test.cl", encoder.encode(VET_SECRET), Constants.ROLE_VETERINARIO, true));
        users.save(new User("inactivo", "off@test.cl", encoder.encode(ADMIN_SECRET), Constants.ROLE_ADMIN, false));
    }

    // ---------- helpers ----------

    private String json(Object value) throws Exception {
        return mapper.writeValueAsString(value);
    }

    private MvcResult doLogin(String username, String secret) throws Exception {
        return mvc.perform(post("/login").contentType(MediaType.APPLICATION_JSON)
                .content(json(new LoginRequest(username, secret)))).andReturn();
    }

    private String tokenFor(String username, String secret) throws Exception {
        MvcResult result = doLogin(username, secret);
        assertEquals(200, result.getResponse().getStatus());
        return result.getResponse().getContentAsString();
    }

    private String adminToken() throws Exception {
        return tokenFor("admin", ADMIN_SECRET);
    }

    private String vetToken() throws Exception {
        return tokenFor("veterinario", VET_SECRET);
    }

    private long createAndGetId(String url, String token, Object body) throws Exception {
        MvcResult result = mvc.perform(post(url).header(AUTH, token)
                .contentType(MediaType.APPLICATION_JSON).content(json(body)))
                .andExpect(status().isOk()).andReturn();
        return mapper.readTree(result.getResponse().getContentAsString()).get("id").asLong();
    }

    // ---------- login ----------

    @Test
    void loginWithValidCredentialsReturnsBearerToken() throws Exception {
        assertTrue(adminToken().startsWith("Bearer "));
    }

    @Test
    void loginWithWrongSecretIsUnauthorized() throws Exception {
        assertEquals(401, doLogin("admin", "incorrecta").getResponse().getStatus());
    }

    @Test
    void loginWithUnknownUserIsUnauthorized() throws Exception {
        assertEquals(401, doLogin("fantasma", ADMIN_SECRET).getResponse().getStatus());
    }

    @Test
    void loginWithDisabledUserIsUnauthorized() throws Exception {
        assertEquals(401, doLogin("inactivo", ADMIN_SECRET).getResponse().getStatus());
    }

    @Test
    void loginWithBlankBodyIsBadRequest() throws Exception {
        mvc.perform(post("/login").contentType(MediaType.APPLICATION_JSON).content("{\"username\":\"\",\"password\":\"\"}"))
                .andExpect(status().isBadRequest());
    }

    // ---------- autenticacion del token ----------

    @Test
    void requestWithoutTokenIsUnauthorized() throws Exception {
        mvc.perform(get("/patient")).andExpect(status().isUnauthorized());
    }

    @Test
    void requestWithGarbageTokenIsUnauthorized() throws Exception {
        mvc.perform(get("/patient").header(AUTH, "Bearer abc.def.ghi")).andExpect(status().isUnauthorized());
    }

    @Test
    void requestWithExpiredTokenIsUnauthorized() throws Exception {
        String expired = new JWTAuthenticationConfig(jwtSigningKey, -1000)
                .getJWTToken("admin", List.of(new SimpleGrantedAuthority(Constants.ROLE_ADMIN)));

        mvc.perform(get("/patient").header(AUTH, expired)).andExpect(status().isUnauthorized());
    }

    @Test
    void tokenWithoutAuthoritiesGetsNoAccess() throws Exception {
        String bareToken = io.jsonwebtoken.Jwts.builder()
                .issuer(Constants.ISSUER_INFO)
                .subject("admin")
                .expiration(new java.util.Date(System.currentTimeMillis() + 60_000))
                .signWith(io.jsonwebtoken.security.Keys.hmacShaKeyFor(io.jsonwebtoken.io.Decoders.BASE64.decode(jwtSigningKey)))
                .compact();

        mvc.perform(get("/patient").header(AUTH, "Bearer " + bareToken)).andExpect(status().isUnauthorized());
    }

    // ---------- roles ----------

    @Test
    void veterinarianCanReadAndCreatePatients() throws Exception {
        String token = vetToken();
        Map<String, Object> patient = Map.of("name", "Firulais", "species", "Perro", "breed", "Labrador", "age", 5, "owner", "Juan Perez");

        long id = createAndGetId("/patient", token, patient);

        mvc.perform(get("/patient").header(AUTH, token)).andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(1));
        mvc.perform(get("/patient/" + id).header(AUTH, token)).andExpect(status().isOk()).andExpect(jsonPath("$.name").value("Firulais"));
    }

    @Test
    void veterinarianCannotDelete() throws Exception {
        String token = vetToken();

        mvc.perform(delete("/patient/1").header(AUTH, token)).andExpect(status().isForbidden());
    }

    @Test
    void adminCanDeletePatients() throws Exception {
        String token = adminToken();
        long id = createAndGetId("/patient", token, Map.of("name", "Michi", "species", "Gato", "age", 3, "owner", "Ana"));

        mvc.perform(delete("/patient/" + id).header(AUTH, token)).andExpect(status().isOk());
        mvc.perform(get("/patient/" + id).header(AUTH, token)).andExpect(status().isNotFound());
    }

    @Test
    void veterinarianCannotUseInvoices() throws Exception {
        mvc.perform(get("/invoice").header(AUTH, vetToken())).andExpect(status().isForbidden());
    }

    @Test
    void unknownRoutesAreBlocked() throws Exception {
        mvc.perform(get("/greetings").header(AUTH, adminToken())).andExpect(status().isForbidden());
    }

    // ---------- validacion ----------

    @Test
    void invalidPatientIsRejected() throws Exception {
        mvc.perform(post("/patient").header(AUTH, adminToken()).contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"\",\"species\":\"Perro\",\"age\":500,\"owner\":\"\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void malformedJsonIsBadRequest() throws Exception {
        mvc.perform(post("/patient").header(AUTH, adminToken()).contentType(MediaType.APPLICATION_JSON).content("{no es json"))
                .andExpect(status().isBadRequest());
    }

    // ---------- encabezados de seguridad ----------

    @Test
    void responsesIncludeSecurityHeaders() throws Exception {
        mvc.perform(get("/patient").header(AUTH, adminToken()))
                .andExpect(status().isOk())
                .andExpect(header().string("X-Content-Type-Options", "nosniff"))
                .andExpect(header().string("X-Frame-Options", "DENY"))
                .andExpect(header().exists("Content-Security-Policy"))
                .andExpect(header().string("Referrer-Policy", "no-referrer"))
                .andExpect(header().exists("Permissions-Policy"))
                .andExpect(header().string("Cross-Origin-Resource-Policy", "same-origin"))
                .andExpect(header().string("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate"));
    }

    // ---------- flujos completos ----------

    @Test
    void appointmentsFullFlow() throws Exception {
        String token = adminToken();
        Map<String, Object> appointment = Map.of("date", "2026-11-01", "time", "10:30:00", "reason", "Control anual", "veterinarian", "Dra. Perez");

        long id = createAndGetId("/appointment", token, appointment);

        mvc.perform(get("/appointment").header(AUTH, token)).andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(1));
        mvc.perform(get("/appointment/" + id).header(AUTH, token)).andExpect(status().isOk()).andExpect(jsonPath("$.reason").value("Control anual"));
        mvc.perform(delete("/appointment/" + id).header(AUTH, token)).andExpect(status().isOk());
    }

    @Test
    void careAndMedicationFullFlow() throws Exception {
        String token = adminToken();

        long careId = createAndGetId("/care", token, Map.of("name", "Consulta", "cost", 15000.0));
        long medId = createAndGetId("/medication", token, Map.of("name", "Antibiotico", "cost", 6000.0));

        mvc.perform(get("/care/" + careId).header(AUTH, token)).andExpect(status().isOk()).andExpect(jsonPath("$.name").value("Consulta"));
        mvc.perform(get("/medication/" + medId).header(AUTH, token)).andExpect(status().isOk()).andExpect(jsonPath("$.name").value("Antibiotico"));
        mvc.perform(get("/care").header(AUTH, token)).andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(1));
        mvc.perform(get("/medication").header(AUTH, token)).andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(1));
        mvc.perform(get("/care/9999").header(AUTH, token)).andExpect(status().isNotFound());
        mvc.perform(delete("/care/" + careId).header(AUTH, token)).andExpect(status().isOk());
        mvc.perform(delete("/medication/" + medId).header(AUTH, token)).andExpect(status().isOk());
    }

    @Test
    void invoiceFullFlowCalculatesTotalAndGeneratesPdf() throws Exception {
        String token = adminToken();
        long careId = createAndGetId("/care", token, Map.of("name", "Consulta", "cost", 15000.0));
        long medId = createAndGetId("/medication", token, Map.of("name", "Antibiotico", "cost", 6000.0));

        long invoiceId = createAndGetId("/invoice", token,
                Map.of("patientName", "Firulais", "date", "2026-10-09", "careIds", List.of(careId), "medicationIds", List.of(medId)));

        mvc.perform(get("/invoice/" + invoiceId).header(AUTH, token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalCost").value(21000.0));
        mvc.perform(get("/invoice").header(AUTH, token)).andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(1));
        mvc.perform(get("/invoice/pdf/" + invoiceId).header(AUTH, token))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_PDF));
        mvc.perform(get("/invoice/pdf/9999").header(AUTH, token)).andExpect(status().isNotFound());
        mvc.perform(delete("/invoice/" + invoiceId).header(AUTH, token)).andExpect(status().isOk());
    }

    @Test
    void invoiceWithUnknownItemsIsBadRequest() throws Exception {
        mvc.perform(post("/invoice").header(AUTH, adminToken()).contentType(MediaType.APPLICATION_JSON)
                .content(json(Map.of("patientName", "Firulais", "date", "2026-10-09", "careIds", List.of(999), "medicationIds", List.of()))))
                .andExpect(status().isBadRequest());
    }

    // ---------- correcciones del escaneo ZAP ----------

    @Test
    void htmlTagsInTextFieldsAreRejected() throws Exception {
        mvc.perform(post("/patient").header(AUTH, adminToken()).contentType(MediaType.APPLICATION_JSON)
                .content(json(Map.of("name", "<script>alert(1)</script>", "species", "Perro", "age", 3, "owner", "Ana"))))
                .andExpect(status().isBadRequest());
    }

    @Test
    void deletingARecordInUseReturnsConflict() throws Exception {
        String token = adminToken();
        long careId = createAndGetId("/care", token, Map.of("name", "Consulta", "cost", 15000.0));
        createAndGetId("/invoice", token,
                Map.of("patientName", "Firulais", "date", "2026-10-09", "careIds", List.of(careId), "medicationIds", List.of()));

        mvc.perform(delete("/care/" + careId).header(AUTH, token)).andExpect(status().isConflict());
    }
}
