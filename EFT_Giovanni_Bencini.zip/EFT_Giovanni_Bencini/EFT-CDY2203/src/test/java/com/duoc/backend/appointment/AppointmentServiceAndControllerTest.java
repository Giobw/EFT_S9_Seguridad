package com.duoc.backend.appointment;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.web.server.ResponseStatusException;

class AppointmentServiceAndControllerTest {

    private final AppointmentRepository repository = mock(AppointmentRepository.class);
    private final AppointmentService service = new AppointmentService(repository);
    private final AppointmentService serviceMock = mock(AppointmentService.class);
    private final AppointmentController controller = new AppointmentController(serviceMock);

    private Appointment sampleAppointment() {
        Appointment appointment = new Appointment();
        appointment.setId(1L);
        appointment.setDate(LocalDate.of(2026, 11, 1));
        appointment.setTime(LocalTime.of(10, 30));
        appointment.setReason("Control anual");
        appointment.setVeterinarian("Dra. Perez");
        return appointment;
    }

    @Test
    void serviceListsFindsSavesAndDeletes() {
        Appointment appointment = sampleAppointment();
        when(repository.findAll()).thenReturn(List.of(appointment));
        when(repository.findById(1L)).thenReturn(Optional.of(appointment));
        when(repository.findById(2L)).thenReturn(Optional.empty());
        when(repository.save(appointment)).thenReturn(appointment);

        assertEquals(1, service.getAllAppointments().size());
        assertSame(appointment, service.getAppointmentById(1L));
        assertNull(service.getAppointmentById(2L));
        assertSame(appointment, service.saveAppointment(appointment));
        service.deleteAppointment(1L);
        verify(repository).deleteById(1L);
    }

    @Test
    void requestIsConvertedToEntity() {
        Appointment appointment = new AppointmentRequest(LocalDate.of(2026, 12, 5), LocalTime.of(9, 0), "Vacuna", "Dr. Soto").toEntity();

        assertEquals(LocalDate.of(2026, 12, 5), appointment.getDate());
        assertEquals(LocalTime.of(9, 0), appointment.getTime());
        assertEquals("Vacuna", appointment.getReason());
        assertEquals("Dr. Soto", appointment.getVeterinarian());
    }

    @Test
    void controllerHandlesAllOperations() {
        when(serviceMock.getAllAppointments()).thenReturn(List.of(sampleAppointment()));
        when(serviceMock.getAppointmentById(1L)).thenReturn(sampleAppointment());
        when(serviceMock.getAppointmentById(99L)).thenReturn(null);
        when(serviceMock.saveAppointment(any(Appointment.class))).thenReturn(sampleAppointment());

        assertEquals(1, controller.getAllAppointments().size());
        assertEquals("Control anual", controller.getAppointmentById(1L).getReason());
        assertThrows(ResponseStatusException.class, () -> controller.getAppointmentById(99L));
        assertEquals(1L, controller.saveAppointment(
                new AppointmentRequest(LocalDate.of(2026, 11, 1), LocalTime.of(10, 30), "Control anual", "Dra. Perez")).getId());
        controller.deleteAppointment(1L);
        verify(serviceMock).deleteAppointment(1L);
    }
}
