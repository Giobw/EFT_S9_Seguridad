package com.duoc.backend.care;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.web.server.ResponseStatusException;

class CareServiceAndControllerTest {

    private final CareRepository repository = mock(CareRepository.class);
    private final CareService service = new CareService(repository);
    private final CareService serviceMock = mock(CareService.class);
    private final CareController controller = new CareController(serviceMock);

    @Test
    void serviceListsFindsSavesAndDeletes() {
        Care care = new Care("Consulta", 15000.0);
        when(repository.findAll()).thenReturn(List.of(care));
        when(repository.findById(1L)).thenReturn(Optional.of(care));
        when(repository.findById(2L)).thenReturn(Optional.empty());
        when(repository.save(care)).thenReturn(care);

        assertEquals(1, service.getAllCares().size());
        assertSame(care, service.getCareById(1L));
        assertNull(service.getCareById(2L));
        assertSame(care, service.saveCare(care));
        service.deleteCare(1L);
        verify(repository).deleteById(1L);
    }

    @Test
    void entityAccessorsWork() {
        Care care = new Care();
        care.setId(3L);
        care.setName("Vacuna");
        care.setCost(8000.0);

        assertEquals(3L, care.getId());
        assertEquals("Vacuna", care.getName());
        assertEquals(8000.0, care.getCost());
        assertEquals("Baño", new CareRequest("Baño", 5000.0).toEntity().getName());
    }

    @Test
    void controllerHandlesAllOperations() {
        Care care = new Care("Consulta", 15000.0);
        when(serviceMock.getAllCares()).thenReturn(List.of(care));
        when(serviceMock.getCareById(1L)).thenReturn(care);
        when(serviceMock.getCareById(99L)).thenReturn(null);
        when(serviceMock.saveCare(any(Care.class))).thenReturn(care);

        assertEquals(1, controller.getAllCares().size());
        assertSame(care, controller.getCareById(1L));
        assertThrows(ResponseStatusException.class, () -> controller.getCareById(99L));
        assertSame(care, controller.saveCare(new CareRequest("Consulta", 15000.0)));
        controller.deleteCare(1L);
        verify(serviceMock).deleteCare(1L);
    }
}
