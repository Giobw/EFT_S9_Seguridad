package com.duoc.backend.medication;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.web.server.ResponseStatusException;

class MedicationServiceAndControllerTest {

    private final MedicationRepository repository = mock(MedicationRepository.class);
    private final MedicationService service = new MedicationService(repository);
    private final MedicationService serviceMock = mock(MedicationService.class);
    private final MedicationController controller = new MedicationController(serviceMock);

    @Test
    void serviceListsFindsSavesAndDeletes() {
        Medication medication = new Medication("Antibiotico", 6000.0);
        when(repository.findAll()).thenReturn(List.of(medication));
        when(repository.findById(1L)).thenReturn(Optional.of(medication));
        when(repository.findById(2L)).thenReturn(Optional.empty());
        when(repository.save(medication)).thenReturn(medication);

        assertEquals(1, service.getAllMedications().size());
        assertSame(medication, service.getMedicationById(1L));
        assertNull(service.getMedicationById(2L));
        assertSame(medication, service.saveMedication(medication));
        service.deleteMedication(1L);
        verify(repository).deleteById(1L);
    }

    @Test
    void entityAccessorsWork() {
        Medication medication = new Medication();
        medication.setId(4L);
        medication.setName("Antiparasitario");
        medication.setCost(4500.0);

        assertEquals(4L, medication.getId());
        assertEquals("Antiparasitario", medication.getName());
        assertEquals(4500.0, medication.getCost());
        assertEquals("Vitamina", new MedicationRequest("Vitamina", 2000.0).toEntity().getName());
    }

    @Test
    void controllerHandlesAllOperations() {
        Medication medication = new Medication("Antibiotico", 6000.0);
        when(serviceMock.getAllMedications()).thenReturn(List.of(medication));
        when(serviceMock.getMedicationById(1L)).thenReturn(medication);
        when(serviceMock.getMedicationById(99L)).thenReturn(null);
        when(serviceMock.saveMedication(any(Medication.class))).thenReturn(medication);

        assertEquals(1, controller.getAllMedications().size());
        assertSame(medication, controller.getMedicationById(1L));
        assertThrows(ResponseStatusException.class, () -> controller.getMedicationById(99L));
        assertSame(medication, controller.saveMedication(new MedicationRequest("Antibiotico", 6000.0)));
        controller.deleteMedication(1L);
        verify(serviceMock).deleteMedication(1L);
    }
}
