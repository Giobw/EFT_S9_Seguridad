package com.duoc.backend.patient;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.web.server.ResponseStatusException;

class PatientServiceAndControllerTest {

    private final PatientRepository repository = mock(PatientRepository.class);
    private final PatientService service = new PatientService(repository);
    private final PatientService serviceMock = mock(PatientService.class);
    private final PatientController controller = new PatientController(serviceMock);

    private Patient samplePatient() {
        Patient patient = new Patient();
        patient.setId(1L);
        patient.setName("Firulais");
        patient.setSpecies("Perro");
        patient.setBreed("Labrador");
        patient.setAge(5);
        patient.setOwner("Juan Perez");
        return patient;
    }

    @Test
    void serviceReturnsAllPatients() {
        when(repository.findAll()).thenReturn(List.of(samplePatient()));

        assertEquals(1, service.getAllPatients().size());
    }

    @Test
    void serviceFindsPatientOrReturnsNull() {
        Patient patient = samplePatient();
        when(repository.findById(1L)).thenReturn(Optional.of(patient));
        when(repository.findById(2L)).thenReturn(Optional.empty());

        assertSame(patient, service.getPatientById(1L));
        assertNull(service.getPatientById(2L));
    }

    @Test
    void serviceSavesAndDeletes() {
        Patient patient = samplePatient();
        when(repository.save(patient)).thenReturn(patient);

        assertSame(patient, service.savePatient(patient));
        service.deletePatient(1L);

        verify(repository).deleteById(1L);
    }

    @Test
    void requestIsConvertedToEntity() {
        Patient patient = new PatientRequest("Michi", "Gato", "Siames", 3, "Ana Gomez").toEntity();

        assertEquals("Michi", patient.getName());
        assertEquals("Gato", patient.getSpecies());
        assertEquals("Siames", patient.getBreed());
        assertEquals(3, patient.getAge());
        assertEquals("Ana Gomez", patient.getOwner());
    }

    @Test
    void controllerListsPatients() {
        when(serviceMock.getAllPatients()).thenReturn(List.of(samplePatient()));

        assertEquals("Firulais", controller.getAllPatients().get(0).getName());
    }

    @Test
    void controllerReturnsPatientById() {
        when(serviceMock.getPatientById(1L)).thenReturn(samplePatient());

        assertEquals("Perro", controller.getPatientById(1L).getSpecies());
    }

    @Test
    void controllerThrowsNotFoundForMissingPatient() {
        when(serviceMock.getPatientById(99L)).thenReturn(null);

        assertThrows(ResponseStatusException.class, () -> controller.getPatientById(99L));
    }

    @Test
    void controllerSavesAndDeletes() {
        when(serviceMock.savePatient(org.mockito.ArgumentMatchers.any(Patient.class))).thenReturn(samplePatient());

        Patient saved = controller.savePatient(new PatientRequest("Firulais", "Perro", "Labrador", 5, "Juan Perez"));
        controller.deletePatient(1L);

        assertEquals(1L, saved.getId());
        verify(serviceMock).deletePatient(1L);
    }
}
