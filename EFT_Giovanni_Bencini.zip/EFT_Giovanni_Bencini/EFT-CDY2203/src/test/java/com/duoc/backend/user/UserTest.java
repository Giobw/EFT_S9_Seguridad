package com.duoc.backend.user;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

class UserTest {

    @Test
    void userExposesRoleAsAuthority() {
        User user = new User("ana", "ana@test.cl", "hash", "ROLE_ADMIN", true);

        assertEquals("ana", user.getUsername());
        assertEquals("ana@test.cl", user.getEmail());
        assertEquals("hash", user.getPassword());
        assertEquals("ROLE_ADMIN", user.getRole());
        assertEquals("ROLE_ADMIN", user.getAuthorities().iterator().next().getAuthority());
        assertTrue(user.isEnabled());
        assertTrue(user.isAccountNonExpired());
        assertTrue(user.isAccountNonLocked());
        assertTrue(user.isCredentialsNonExpired());
    }

    @Test
    void settersUpdateTheUser() {
        User user = new User();
        user.setId(5);
        user.setUsername("luis");
        user.setEmail("luis@test.cl");
        user.setPassword("otro-hash");
        user.setRole("ROLE_VETERINARIO");
        user.setEnabled(false);

        assertEquals(5, user.getId());
        assertEquals("luis", user.getUsername());
        assertEquals("ROLE_VETERINARIO", user.getAuthorities().stream().map(GrantedAuthority::getAuthority).findFirst().orElse(""));
        assertFalse(user.isEnabled());
    }

    @Test
    void userDetailsServiceReturnsExistingUser() {
        UserRepository repository = mock(UserRepository.class);
        User user = new User("ana", "ana@test.cl", "hash", "ROLE_ADMIN", true);
        when(repository.findByUsername("ana")).thenReturn(user);

        UserDetails result = new MyUserDetailsService(repository).loadUserByUsername("ana");

        assertEquals("ana", result.getUsername());
    }

    @Test
    void userDetailsServiceFailsForUnknownUser() {
        MyUserDetailsService service = new MyUserDetailsService(mock(UserRepository.class));

        assertThrows(UsernameNotFoundException.class, () -> service.loadUserByUsername("nadie"));
    }
}
